#if defined HAVE_CONFIG_H
#include "config.h"
#endif

#define _XOPEN_SOURCE

//TODO include selon ce qu'il y a dans le .h

#include "utils.h"
#include "myassert.h"

#include "client_master.h"

//TODO fonctions selon ce qu'il y a dans le .h

